exports.handler = async (event) => { return { statusCode: 200, body: "Logging Service Response" }; };
